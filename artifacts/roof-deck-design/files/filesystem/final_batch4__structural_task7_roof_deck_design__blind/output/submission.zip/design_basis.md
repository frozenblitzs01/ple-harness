# Design Basis — DC-2 Helena Data Centre, Building A Roof Deck

## 1. Executive Summary & Governing Documents
The roof deck design for Building A of the DC-2 Helena Data Centre has been developed in accordance with the project structural design criteria (`EOR-DC-RD-01 Rev 2`), lateral analysis report (`LAT-2026-003 Rev 1`), site-specific snow study (`SNOW-2026-014 Rev 0`), owner's basis of design (`OBD-DC2-A`), and referenced national standards (IBC, ASCE 7-22 via UFC 3-301-01). Where discrepancies exist between 2D drawings and the 3D coordination model (`DC2-A-STR Rev C`), the model and current transmittal (`T-118`) govern.

## 2. Snow and Seismic Bases
- **Ground Snow Load (`pg`)**: Established by site-specific case study `SNOW-2026-014` as **63 psf** (Risk Category II basis, 50-year MRI).
- **Snow Parameters**: Exposure factor $C_e = 0.90$ (Terrain Category C, partially exposed roof), thermal factor $C_t = 1.00$ (heated structure), snow importance factor $I_s = 1.10$ for Risk Category III.
- **Flat Roof Snow Load (`pf`)**: $0.7 	imes 0.90 	imes 1.00 	imes 1.10 	imes 63 = \mathbf{43.66	ext{ psf}}$.
- **Snow Density ($\gamma$)**: $0.13 	imes 63 + 14 = \mathbf{22.19	ext{ pcf}}$ (capped at 30 pcf). Balanced snow depth $h_b = 1.968	ext{ ft}$.
- **Seismic Parameters**: $S_{DS} = 0.44$, $S_{D1} = 0.24$, Site Class D, Seismic Design Category D, Seismic importance factor $I_e = 1.25$, response modification coefficient $R = 3.25$ for ordinary concentrically braced frames, overstrength factor $\Omega_0 = 2.0$.
- **Effective Seismic Weight**: Roof dead weight of 18.0 psf plus 20% of flat roof snow load ($0.20 	imes 43.66 = 8.73	ext{ psf}$), totaling $\mathbf{26.73	ext{ psf}}$, giving a roof diaphragm design force $F_{px} = \mathbf{195.42	ext{ kips}}$.

## 3. Diaphragm Analysis and Classification
The roof diaphragm was analysed as an in-plane semi-rigid diaphragm across all lateral load scenarios ($S05$ to $S10$). The maximum in-plane shear occurs under seismic load along Y ($S08$) at **440.0 plf**, and maximum in-plane deflection is **0.75 in**, which is well within the 1.60 in serviceability limit (`EOR-DC-RD-01` clause 9.2). The diaphragm is classified as **Semi-rigid** per clause 9.3.

## 4. Zoning and Procurement Strategy
- **Gages**: Restricted to **20 gage** and **18 gage**. 16 gage was evaluated but rejected due to its 14-week mill order lead time exceeding the Owner's 9-week release-to-site procurement allowance (`OBD-DC2-A` section 5).
- **Zones & Patterns**: Three distinct zones (`ZONE-PERIM`, `ZONE-INT`, `ZONE-DRIFT`) utilizing two attachment patterns (`36/4` with 2 screw sidelaps and `36/7` with 3 screw sidelaps). All perimeter and opening edges satisfy the mandatory `36/7` and 3 sidelap minimum (`EOR-DC-RD-01` clause 10.4).
- **Cost Optimization**: The selected zoning minimizes indirect set-up costs while satisfying all structural strength, uplift, and diaphragm shear demands at the lowest installed cost.
